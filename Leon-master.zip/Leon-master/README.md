## Leon
**A Simple WhatsApp Bot.**

## ⚙️ Setup ⚙️

```
pkg install git
pkg install nodejs
git clone https://github.com/TOXIC-DEVIL/Leon
cd Leon
npm i @adiwajshing/baileys
npm i chalk
node index.js
```
  
## 💫 Deploy & Run Leon 💫

[![Run on Repl.it](https://repl.it/badge/github/TOXIC-DEVIL/WhatsApp-Bot)](https://replit.com/@TOXICDEVIL/Leon)

[![Deploy-Leon](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/TOXIC-DEVIL/Leon)

**Found a bug/glitch is bot? Or wanna feedback us? [`Mail Us Here!`](mailto:leon.toxicdevil@gmail.com)**

## ⚠ Warning ⚠

```
By using kick, add, promote, demote Commands, Your WhatsApp account may be banned.
Leon or we are not responsible for your account, 
This bot is intended for the purpose of having fun with some fun commands 
and group management with some helpfull commands.

If  you ended up spamming groups, getting reported left and right, 
and you ended up in being fight with WhatsApp
and at the end WhatsApp Team deleted your account. DON'T BLAME US.

No personal support will be provided / We won't spoon feed you. 
If you need help
you can contact - 
```
[`MAIL LEON`](mailto:leon.toxicdevil@gmail.com)

## 👨‍💻 Developers & Contributors 👨‍💻

 [![TOXIC-DEVIL](https://github.com/TOXIC-DEVIL.png?size=100)](https://github.com/TOXIC-DEVIL) |
----|
[TOXIC-DEVIL](https://github.com/TOXIC-DEVIL)  | 
Author: Developer, Base, Bug Fixes, Commits, Modules | 

## THANKS TO

- **[Adiwajshing](https://github.com/Adiwajshing) for [`Baileys`](https://github.com/adiwajshing/Baileys)**

- **[TOXIC DEVIL](https://github.com/TOXIC-DEVIL) for [`TOXIC DEVIL API - FREE REST API`](https://api-toxic-devil.herokuapp.com/)**

- **And all.**
